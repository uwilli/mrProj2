#include "lsm6ds33.h"
#include "unistd.h" // sleep

#include "pca9554b.h"

int main()
{
    Pca9554b expander;
    expander.initialise();

    return 0;
}
